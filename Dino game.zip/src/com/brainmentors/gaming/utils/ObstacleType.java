package com.brainmentors.gaming.utils;

import java.awt.image.BufferedImage;

public interface ObstacleType {
	public static final BufferedImage Flyingobstacle [] = new BufferedImage[2];
	BufferedImage Cactusobstacle [] = new BufferedImage[1];
	BufferedImage Rockobstacle [] = new BufferedImage[1];
	
	static void FlyingObstacle(BufferedImage spriteImage) {
		Flyingobstacle[0] = spriteImage.getSubimage(597,53,89,64);
		Flyingobstacle[1] = spriteImage.getSubimage(688,41,87,62);
		
	}
	static void Cactus(BufferedImage spriteImage) {
		Cactusobstacle[0]  = spriteImage.getSubimage(599,136,17,38);
	
	}
	static void Rock(BufferedImage spriteImage) {
		Rockobstacle[0] = spriteImage.getSubimage(711,346,44,25);
		
	}
	

}
