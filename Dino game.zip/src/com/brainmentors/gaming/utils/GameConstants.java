package com.brainmentors.gaming.utils;

public interface GameConstants {
	String TITLE  = "Dino game";
	int GWIDTH = 1280;
	int GHEIGHT =400;
	int FLOOR  = GHEIGHT - 80; 
	int WALK = 2;
	int STAND = 1;
	int FALL = 3;
	int GRAVITY = 5;
    int DELAY = 90;
	int MAX_ENEMIES = 20;
	
	

}
