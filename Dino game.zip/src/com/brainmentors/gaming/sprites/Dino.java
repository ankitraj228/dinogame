package com.brainmentors.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import com.brainmentors.gaming.utils.GameConstants;

public class Dino extends Sprite  {
	
	private BufferedImage standImages [] = new BufferedImage[2];
	private BufferedImage walkImages [] = new BufferedImage[5];
	private boolean isAttacking;
	private int force;
	private boolean isJump ;
	public Dino() throws Exception {
		x  = 180;
		speed = 0;
		force = 0;
		currentMove = STAND;
		loadstand();
		loadwalk();
	}
	
	
	
	
	
	public boolean isAttacking() {
		return isAttacking;
	}

	public void setAttacking(boolean isAttacking) {
		this.isAttacking = isAttacking;
	}


	private void loadstand() {
		standImages[0] = bi.getSubimage(55,46,52,54);
		standImages[1] = bi.getSubimage(109,46,53,55);
		
		
	}
	
	private void loadwalk() {
		walkImages[0] = bi.getSubimage(161,47,55,55);
		walkImages[1] = bi.getSubimage(215,46,55,55);
		walkImages[2] = bi.getSubimage(55,46,52,54);
		walkImages[3] = bi.getSubimage(161,47,55,55);
		walkImages[4] = bi.getSubimage(215,46,55,55);
	}
	
	public void jump() {
		if(!isJump) {
		force = -40;
		y = y + force;
		isJump = true;
		}
	}
	
	public void fall() {

		if(y>=(FLOOR-h) && isAlive) {
			isJump= false; 
			return ;
		}
		force = force + GRAVITY;
		y= y + force;
	}
	
	
	public boolean isJump() {
		return isJump;
	}

	private BufferedImage showdinowalk() {
		if(index >4) {
			index =0;
			currentMove = STAND;
			isAttacking = false;
		}
		BufferedImage img =  walkImages[index];
		index++;
		return img;
		
	}


	private BufferedImage showdinostand() {
		if(index >1) {
			index =0;
		}
	
		BufferedImage img =  standImages[index];
		index++;
		return img;
		
	}
	
	
	@Override
	public void printSprite(Graphics pen) {
		if(currentMove == STAND) {
		pen.drawImage(showdinostand(),x, y, w, h, null);
		}
		else if (currentMove == WALK) {
			
			pen.drawImage(showdinowalk(),x, y, w, h, null);
		}
	}
	

}
