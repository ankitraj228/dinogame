package com.brainmentors.gaming.screens;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.swing.JPanel;
import javax.swing.Timer;

import com.brainmentors.gaming.sprites.Camera;
import com.brainmentors.gaming.sprites.Obstacle;
import com.brainmentors.gaming.sprites.Dino;
import com.brainmentors.gaming.utils.ObstacleType;
import com.brainmentors.gaming.utils.GameConstants;

public class Board extends JPanel implements GameConstants {
	private Camera camera;
	BufferedImage backgroundImage;
	BufferedImage partOfImage;
	private Dino dino;
	private Obstacle obstacles[] ;
	private Obstacle obstacle;
	private Timer timer;
	private boolean isGameOver;
	
	
	public Board() throws Exception{
		dino = new Dino();
		ObstacleType.Cactus(dino.getSpriteImage());
		ObstacleType.FlyingObstacle(dino.getSpriteImage());
		ObstacleType.Rock(dino.getSpriteImage());
		obstacles = new Obstacle[MAX_ENEMIES];
		loadEnemies();
		loadBackgroundImage();
		setFocusable(true);
		bindEvents();
		gameLoop();
		
	}	
	
	private void loadEnemies() throws Exception {
		int gap = 0;
		for(int i = 0 ; i<obstacles.length; i++) {
			if(i%2==0) {
				obstacles[i] = new Obstacle(ObstacleType.Cactusobstacle, gap);
			}
			else if(i%3==0) {
				obstacles[i] = new Obstacle(ObstacleType.Rockobstacle, gap);
			}
			else {
				obstacles[i] = new Obstacle(ObstacleType.Flyingobstacle, gap);
			}
			
			gap = gap + 500;
		}
	}
	
	
	
	private void gameLoop() {
		timer = new Timer(DELAY, new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
					repaint();
					if(isGameOver) {
						timer.stop();
					}
					dino.fall();
					collision();
					camera.setSpeed(10);
					camera.move();
					if(!dino.isJump()) {
						dino.setCurrentMove(WALK);
					}
				
			}
		});
		timer.start();
	}
	
	private void bindEvents() {
		this.addKeyListener(new KeyAdapter() {
			
			
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				
				 if (e.getKeyCode() == KeyEvent.VK_SPACE) {
						dino.jump();
					}
				
			}
		});
	}
	
	private void loadBackgroundImage() throws IOException {
		camera = new Camera();
	}
	
	private boolean isCollide(Obstacle currentEnemy) {
		int xDistance = Math.abs(dino.getX() - currentEnemy.getX());
		int yDistance = Math.abs(dino.getY() - currentEnemy.getY());
		int maxWidth = Math.max(dino.getW(), currentEnemy.getW());
		int maxHeight = Math.max(dino.getH(), currentEnemy.getH());
		return xDistance<=maxWidth-30 && yDistance<=maxHeight-20;
	}
	
	
	private void printGameOver(Graphics pen) {
		if(isGameOver) {
		pen.setColor(Color.BLACK);
		pen.setFont(new Font("Arial", Font.BOLD, 80));
		pen.drawString("Game Over !!!", GWIDTH/2-230, GHEIGHT/2);
		}
		
	}
	
	public void collision() {
		for(Obstacle enemy : obstacles) {
			if(!enemy.isCollide()  && isCollide(enemy)) {
				
				enemy.setCollide(true);

				isGameOver = true;
			}
		}
	}
	
	@Override
	public void paintComponent(Graphics pen) {
		super.paintComponent(pen);
		printBG(pen);
		dino.printSprite(pen);
		printEnemies(pen);
		if(isGameOver) {
			printGameOver(pen);
		}
	}
	
	private void printEnemies(Graphics pen) {
		for(Obstacle en: obstacles) {
			if(en.isAlive()) {
			en.printSprite(pen);
			}
		}
	}
	
	private void printBG(Graphics pen) {
		camera.printSprite(pen);
		
	}

}
